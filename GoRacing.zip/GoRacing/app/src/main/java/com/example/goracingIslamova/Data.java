package com.example.goracingIslamova;

public class Data {
    public static String playerName = "Player";
}
