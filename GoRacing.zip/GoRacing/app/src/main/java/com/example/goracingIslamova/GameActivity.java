package com.example.goracingIslamova;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class GameActivity extends AppCompatActivity {

    private ImageView iv_pccar, iv_usecar, iv_finishline;
    private TextView tv_timer, tv_semafor = (TextView) findViewById(R.id.tv_semafor);
    Timer timeGame = new Timer();
    Timer timerPC = new Timer();
    int state = 0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        iv_pccar = (ImageView) findViewById(R.id.iv_pccar);
        iv_usecar = (ImageView) findViewById(R.id.iv_usercar);
        iv_finishline = (ImageView) findViewById(R.id.iv_finishline);
        tv_timer = (TextView) findViewById(R.id.tv_timer);
    }

    public void startGameAction(View view) {
        timeGame();
        timerPC();
    }

    public void timerGame() {
        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                    }
                });
            }
        }
    }

    public void driveCarAction(View view) {
        if (state == 2) {
            iv_usecar.setX(iv_usecar.getX() + 30);
        }
        if (state == 1) {
            iv_usecar.setX(iv_usecar.getX() - 30);
        }
        if (iv_usecar.getX() >= iv_finishline.getX()) {
            timerPC.cancel();
            timeGame.cancel();
            Toast.makeText(getApplicationContext(), "YOU WIN", Toast.LENGTH_LONG).show();
        }
    }

    public void timerGame() {
        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        state += 1;
                        if (state > 2)
                            state = 1;
                        switch (state) {
                            case 1:
                                tv_semafor.setText("RED");
                                tv_semafor.setTextColor(Color.RED);
                                break;
                            case 2:
                                tv_semafor.setText("GREEN");
                                tv_semafor.setTextColor(Color.GREEN);
                                break;
                        }
                    }
                });
            }
        };
        timeGame.scheduleAtFixedRate(timerTask, 0, 3000);
    }
}
